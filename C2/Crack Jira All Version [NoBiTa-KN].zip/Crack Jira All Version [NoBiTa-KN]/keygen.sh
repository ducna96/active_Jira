#!/bin/bash
jarfile=JiraActiveAllVersion.jar
check=`which java`
pkgJfx="openjfx"
if [ -f `pwd`/$jarfile ]
then
	if [ -n "$check" ]
	then
		if dpkg --get-selections | grep -q "^$pkgJfx[[:space:]]*install$" >/dev/null; then
    			java -jar $jarfile
		else
    			echo "$pkgJfx NOT installed. Please install JavaFX (sudo apt-get install openjfx) and try again."
		fi
	else
		echo -e "Failed to locate java executable!\nPlease install Java Runtime Environment (JRE) and try again."
	fi
else
	echo "Failed to locate $jarfile."
fi
